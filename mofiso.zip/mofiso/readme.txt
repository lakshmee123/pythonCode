python manage.py runserver
python manage.py migrate
python manage.py createsuperuser

** For html template render
from django.shortcuts import render