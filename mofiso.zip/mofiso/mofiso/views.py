from django.http import HttpResponse
from django.shortcuts import render
def homePage(request):
    # data={
    #     'title':'Home Page',
    #     'list':['name','mobileNo'],
    #     'productdetails':[
    #         {'name':'bag','price':'0987654321'},
    #         {'name':'bag','price':'0987654321'}
    #     ]
    # }
    return render(request,"index.html")
def aboutUs(request):
    return HttpResponse("<b>Welcome About Us</b>")
def productDetail(request,product_id):
    return HttpResponse(product_id)